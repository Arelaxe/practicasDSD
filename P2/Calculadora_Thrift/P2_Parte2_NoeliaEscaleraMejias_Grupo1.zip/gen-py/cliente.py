from calculadora import Calculadora

from thrift import Thrift
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol

transport = TSocket.TSocket('localhost', 9090)
transport = TTransport.TBufferedTransport(transport)
protocol = TBinaryProtocol.TBinaryProtocol(transport)

client = Calculadora.Client(protocol)

transport.open()

client.ping()

r_suma = client.suma(3,4)
r_resta = client.resta(3,4)
r_mult = client.multiplicar(3,4)
r_div = client.dividir(3,4)
v1 = [1,2,3]
v2 = [-4,5,6]
v3 = [1,1,1]
r_prod_esc = client.producto_escalar(v1,v2)
r_esc_v = client.escalar_por_vector(2,v1)
r_suma_v = client.suma_vectores(v1,v2)
r_resta_v = client.resta_vectores(v1,v2)
r_prod_v = client.producto_vectorial(v1,v2)
r_prod_m = client.producto_mixto(v1,v2,v3)
r_media = client.media(v2)
r_pot = client.potencia(2,3)

print('3+4='+str(r_suma))
print('3-4='+str(r_resta))
print('3*4='+str(r_mult))
print('3/4='+str(r_div))
print('Producto escalar de {1,2,3} y {-4,5,6}: '+str(r_prod_esc))
print('2*{1,2,3}: '+str(r_esc_v))
print('{1,2,3}+{-4,5,6}='+str(r_suma_v))
print('{1,2,3}-{-4,5,6}'+str(r_resta_v))
print('{1,2,3}x{-4,5,6}'+str(r_prod_v))
print('Producto mixto de {1,2,3}, {-4,5,6} y {1,1,1}: '+str(r_prod_m))
print('Media de -4, 5 y 6: '+str(r_media))
print('2^3='+str(r_pot))

transport.close()