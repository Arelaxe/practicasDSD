import glob
import sys

from calculadora import *
from calculadora.ttypes import *

from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol
from thrift.server import TServer

import logging
logging.basicConfig(level=logging.DEBUG)

import numpy

class CalculadoraHandler:
    def __init__(self):
        self.log = {}

    def ping(self):
        print('Me han hecho ping()')

    def suma(self, num1, num2):
        return num1 + num2

    def resta(self, num1, num2):
        return num1 - num2

    def multiplicar(self, num1, num2):
        return num1 * num2

    def dividir(self, num1, num2):
        return num1 / num2

    def producto_escalar(self, v1, v2):
        r = 0.0
        for i in range(0,len(v1)):
            r += v1[i]*v2[i]
        return r

    def escalar_por_vector(self,n,v):
        r = []
        for i in range(0,len(v)):
            r.append(n*v[i])
        return r

    def suma_vectores(self,v1,v2):
        r = []
        for i in range(0,len(v1)):
            r.append(v1[i]+v2[i])
        return r

    def resta_vectores(self,v1,v2):
        r = []
        for i in range(0,len(v1)):
            r.append(v1[i]-v2[i])
        return r

    def producto_vectorial(self,v1,v2):
        r = numpy.full(3,0)
        r[0]=v1[1]*v2[2]-v1[2]*v2[1]
        r[1]=v1[2]*v2[0]-v1[0]*v2[2]
        r[2]=v1[0]*v2[1]-v1[1]*v2[0]
        return r

    def producto_mixto(self,v1,v2,v3):
        v = []
        r = 0
        v.append(v2[1]*v3[2]-v2[2]*v3[1])
        v.append(v2[2]*v3[0]-v2[0]*v3[2])
        v.append(v2[0]*v3[1]-v2[1]*v3[0])
        for i in range(0,len(v1)):
            r += v1[i]*v[i]
        return r

    def media(self,v1):
        r = 0
        for i in range(0,len(v1)):
            r += v1[i]
        r /= len(v1)
        return r

    def potencia(self,base,exponente):
        r = base**exponente
        return r

if __name__ == '__main__':
    handler = CalculadoraHandler()
    processor = Calculadora.Processor(handler)
    transport = TSocket.TServerSocket(host='127.0.0.1', port=9090)
    tfactory = TTransport.TBufferedTransportFactory()
    pfactory = TBinaryProtocol.TBinaryProtocolFactory()

    server = TServer.TSimpleServer(processor, transport, tfactory, pfactory)

    print('Iniciando servidor...')
    server.serve()
    print('done.')